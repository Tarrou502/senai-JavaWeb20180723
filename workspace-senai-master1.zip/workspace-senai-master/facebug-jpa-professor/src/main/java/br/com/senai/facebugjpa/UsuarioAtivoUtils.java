package br.com.senai.facebugjpa;

public class UsuarioAtivoUtils {
	public static Usuario usuario;
}
