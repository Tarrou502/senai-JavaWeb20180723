package br.com.senai.facebugjpa;

import org.springframework.data.repository.CrudRepository;

public interface UsuarioDAO extends CrudRepository<Usuario, String>{

}
