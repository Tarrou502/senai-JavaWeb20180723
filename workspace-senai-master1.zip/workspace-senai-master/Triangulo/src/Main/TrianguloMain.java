package Main;

import beans.Triangulo;

public class TrianguloMain {	
	public static void main(String[] args) {
			
		String letra;
		Triangulo tri = new Triangulo();
		letra = tri.exibeLetra();
		System.out.println(letra);

	}
	
}



