package br.com.senai.facebugspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacebugSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacebugSpringApplication.class, args);
	}
}
