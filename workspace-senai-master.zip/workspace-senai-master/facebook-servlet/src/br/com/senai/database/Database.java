package br.com.senai.database;

import java.util.HashMap;

import br.com.senai.models.Usuario;

public class Database {
	public static final HashMap<String, Usuario> USUARIOS = new HashMap<>();
}
