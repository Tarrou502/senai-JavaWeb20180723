package br.com.senai.utils;

public class Context {
	public static Boolean isLogged = Boolean.FALSE;
}
