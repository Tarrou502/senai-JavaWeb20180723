package br.com.senai.facebugthymeleaf;

import java.time.LocalDateTime;

public class Timer {
	public static final LocalDateTime getDataHora() {
		return LocalDateTime.now();
	}
}
